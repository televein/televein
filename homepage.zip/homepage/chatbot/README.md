## Documentation

[A Comprehensive Guide to Creating a simple chatbot using html css and JavaScript](https://medium.com/@aakashthoriya/basic-chatbot-using-html-css-and-javascript-f534e202befd)
