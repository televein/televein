// function startChat() {
//     var name =  document.getElementById('name').value;

//     if (name.trim() !== '') {
//         alert('Hello ' + name + '! Welcome to VSBEC Chatbot!');
//         // Here you can proceed with your chatbot logic
//     } else {
//         alert('Please enter your name.');
//     }
// }
// var na="gokul"
// window.onload = function() {
//     var getInput = na;
//     localStorage.setItem("storageName",getInput);
//  }
const handlesubmit = function() {
var na = document.getElementById('name');
    // var na= document.getElementById('name').value;
    var input =na.value;
    console.log(input)

    var getInput = input;
    localStorage.setItem("storageName",getInput);
 }